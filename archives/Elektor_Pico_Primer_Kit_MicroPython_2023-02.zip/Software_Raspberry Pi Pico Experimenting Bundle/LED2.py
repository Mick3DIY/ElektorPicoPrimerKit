#---------------------------------------------------------
#		ALTERNATELY FLASHING LEDs
#		=========================
#
# In this program the on-board yellow and green LEDs are
# flashed alternately
#
# Author: Dogan Ibrahim
# File  : LED2.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime

YLED = Pin(18, Pin.OUT)			# Yellow LED
GLED = Pin(19, Pin.OUT)			# Green LED

while True:
    YLED.value(0)			# Yellow ON
    GLED.value(1)			# Green OFF
    utime.sleep(0.5)
    YLED.value(1)			# Yellow OFF
    GLED.value(0)			# Green ON
    utime.sleep(0.5)

