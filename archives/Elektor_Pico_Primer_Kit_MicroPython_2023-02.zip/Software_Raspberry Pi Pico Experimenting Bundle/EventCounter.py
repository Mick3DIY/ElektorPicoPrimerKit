#-----------------------------------------------------
#	  	EVENT COUNTER
#	  	=============
#
# This is an event counter program. The program counts
# external events and displays on the TFT. Button K1
# simulates the occurence of external events
#
# Author: Dogan Ibrahim
# File  : EventCounter.py
# Date  : March, 2022
#------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin
import utime

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
sck=Pin(10), mosi=Pin(11), miso=Pin(12))

ButtonK1=Pin(2,Pin.IN)   		        # Button K1 at GP2
tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

tft.fill(TFT.BLACK)						# Clear screen
Count = 1

#
# Display heading
#
tft.rect((10, 10), (110, 100), TFT.WHITE)
tft.text((19, 40), "EVENT COUNTER", TFT.WHITE, sysfont, 
1.1, nowrap=True)

#
# Wait for the button to be pressed and then released and
# then increment the event count
#
while True:
   while ButtonK1.value() == 1:			# Wait for button press
      pass
   while ButtonK1.value() == 0:			# Wait for button release
      pass
      
   tft.text((20, 60), "Count:{:d}".format(Count), TFT.WHITE, 
   sysfont, 1, nowrap=True)
   Count = Count + 1

   
  










