#-----------------------------------------------------
#	  	VARIOUS SHAPES
#	  	==============
#
# This program draws various shapes on the TFT display
#
# Author: Dogan Ibrahim
# File  : TFTBasic.py
# Date  : October, 2022
#------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
sck=Pin(2), mosi=Pin(3), miso=Pin(4))

tft = TFT(spi, 15, 14, 5)
tft.initg()
tft.rgb(True)   

tft.fill(TFT.BLACK)				     # Clear screen

tft.rect((0, 0), (50, 50), TFT.RED)		# Hollow rect
tft.fillrect((60, 0), (50, 50), TFT.BLUE)	# Filled rect
tft.circle((20, 70), 15, TFT.RED)		# Hollow circle
tft.fillcircle((60, 70), 15, TFT.GREEN)		# Filled circle
tft.line((20, 90), (60, 100), TFT.YELLOW)	# Line
tft.hline((20, 110), 80, TFT.CYAN)		# Horiz line
tft.vline((110, 60), 70, TFT.CYAN)		# Vert line








