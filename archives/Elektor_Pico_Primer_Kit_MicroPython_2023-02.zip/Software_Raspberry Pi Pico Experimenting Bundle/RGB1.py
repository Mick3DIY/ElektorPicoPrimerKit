#==========================================================
#                WS2812 8-LED RING
#                =================
#
# In this project the WS2812 8-LED RGB ring is connected
# to the development board. The LEDs are turned ON ann OFF
# in various forms to make it visually attractive
#
# Author: Dogan Ibrahim
# FIle  : RGB1.py
# Date  : March, 2022
#===========================================================
import machine, neopixel
import utime

n = 8                                         # No of LEDs
np = neopixel.NeoPixel(machine.Pin(16), n)    # At IO16

#
# Clear all
#
def clear():
    for i in range(n):
        np[i] = (0, 0, 0)
        np.write()
#
# Set colour
#
def set_colour(r, g, b):
    for i in range(n):
        np[i] = (r, g, b)
    np.write()

#
# Cycle
#
def cycle(r, g, b, tim):
    for i in range(4 * n):
        for j in range(n):
            np[j] = (0, 0, 0)
        np[i % n] = (r, g, b)
        np.write()
        utime.sleep_ms(20)
               
while True:
    clear()
    set_colour(0, 102, 230)
    utime.sleep(1)
    cycle(255, 255, 255, 20)                # Cycle White
    
