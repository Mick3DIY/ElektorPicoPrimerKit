#----------------------------------------------------------------
#		REACTION TIMER
#		==============
#
# This is a reaction timer program which measures the reaction
# of the user and displays on the Thonny screen in ms. For a
# fast reaction time, the user should press the pushbutton as 
# soon as the LED is lit
#
# Author: Dogan Ibrahim
# File  : Reaction.py
# Date  : February 2022
#------------------------------------------------------------------
from machine import Pin
import utime
import random

Button = Pin(2, Pin.IN)					# Pushbutton K1
LED = Pin(18, Pin.OUT)					# Yellow LED
flag = 0

#
# This is the interrupt service routine. The program jumps here
# as soon as the pushbutton is pressed
#
def MyButton(pin):
    global flag
    Button.irq(handler = None)
    LED.value(1)					        # LED OFF
    TmrEnd = utime.ticks_ms()				# End of time
    ReactionTime = utime.ticks_diff(TmrEnd, TmrStart)
    flag = 1
    print("Reaction Time: %fms" %(ReactionTime))		# Display reaction time
    utime.sleep(3)

#
# Start of MAIN program. Generate a random delay and then turn ON LED
#
LED.value(1)					        # LED OFF

while True:					            # DO FOREVER
    flag = 0
    rnd = random.randint(3, 10)			# Random integer number
    utime.sleep(rnd)				    # Delay random
    LED.value(0)				        # LED ON
    TmrStart = utime.ticks_ms()
    Button.irq(handler=MyButton, trigger = Pin.IRQ_FALLING)
    while flag == 0:
       pass
       

