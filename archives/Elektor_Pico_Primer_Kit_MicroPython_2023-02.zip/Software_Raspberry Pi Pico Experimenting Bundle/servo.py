#----------------------------------------------------------
#				SIMPLE SERVO CONTROL
#				====================
#
# In this project a SG90 type servo is connected to the
# development board. The program rotates the motor from -45
# to +45 degrees continuously
#
# Author: Dogan Ibrahim
# File  : servo.py
# Date  : March, 2022
#-----------------------------------------------------------
from machine import Pin, PWM    
import utime

servo = PWM(Pin(16))
servo.freq(50)

while True:
    for i in range(3277, 6553, 100): 
       servo.duty_u16(i)
       utime.sleep_ms(100)
     
    utime.sleep(2)
       
    for i in range(6553, 3277, -100):
        servo.duty_u16(i)
        utime.sleep_ms(100)
        
    utime.sleep(2)
    
        
   
    
