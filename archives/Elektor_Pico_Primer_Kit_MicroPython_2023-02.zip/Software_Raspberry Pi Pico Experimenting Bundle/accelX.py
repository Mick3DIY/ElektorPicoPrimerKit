#---------------------------------------------------------
#		MAXIMUM ACCELERATION IN X DIRECTION
#		===================================
#
# This program reads the acceleration from the MPU6050
# module and displays the maximum acceleration in the X
# direction on the TFT display
#
# Author: Dogan Ibrahim
# File  : accelX.py
# Date  : March, 2022
#----------------------------------------------------------
from imu import MPU6050
import utime
from machine import Pin, I2C, SPI
from ST7735 import TFT
from sysfont import sysfont

i2c = I2C(0, sda=Pin(8), scl=Pin(9), freq=400000)
imu = MPU6050(i2c)

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

#
# Read and display the acceleration in X direction. Note that
# display is updated if there is a change and the maximum
# value of the acceleration is displayed
#
Amax = 0
tft.fill(TFT.WHITE)							# Clear screen

while True:									# Do forever
    Ax = round(imu.accel.x,2)				# Acc in X
    if Ax != Amax:							# Change?
       if Ax > Amax:						# New max?
          Amax = Ax							# Get maximum
          tft.fill(TFT.WHITE)
          tft.text((25, 10), "Acc X", TFT.BLACK, sysfont, 2, nowrap=True)
          tft.text((10, 50), "X:", TFT.BLACK, sysfont, 2, nowrap=True)
          tft.text((10, 70), "{}".format(Ax), TFT.BLACK, sysfont, 2, nowrap=True)

  
