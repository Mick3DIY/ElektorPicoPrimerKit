#---------------------------------------------------------
#		LEVEL GRAPHIC USING THE GYROSCOPE
#		=================================
#
# In this program the gyroscope on the MPU6050 module
# is used. The gyroscope in 3 dimensions is displayed
# on the Thonny screen. Additionally, the TFT display
# shows a dynamic circle whose position changes as the
# level of the module is changed
#
# Author: Dogan Ibrahim
# File  : leveling.py
# Date  : March, 2022
#
# Note: Part of this program has been taken from the Makerfabs
# web site and has been modified for the book
#----------------------------------------------------------
#
# Library modules used in the program
#
from imu import MPU6050
import utime
from machine import Pin, I2C, SPI
from ST7735 import TFT
from sysfont import sysfont

#
# Initiaize the I2C and SPI busses
#
i2c = I2C(0, sda=Pin(8), scl=Pin(9), freq=400000)
imu = MPU6050(i2c)

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

#
# Main program. Read the gyroscope values and display them
# on the Thonny screen. Also, display the x and y gyroscope
# values on the TFT display in the form of a circle. X and Y
# coordinates are displayed on the TFT
#
def main():
    tft.initg()
    tft.rgb(True)
    tft.fill(TFT.BLACK)
    tft.text((30, 0), "X Direct", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.rotation(1)
    tft.text((30, 0), "Y Direct", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.rotation(0)
    
    last_Gx, last_Gy = 64, 64

    while True:
        gx = imu.gyro.x
        gy = imu.gyro.y
        gz = imu.gyro.z
        Gx, Gy = (int)(64 + gx * 30), (int)(64 + gy * -30)

        if last_Gx != Gx and last_Gy != Gy:
            tft.circle((last_Gx, last_Gy), 15, TFT.BLACK)
            tft.circle((Gx, Gy), 15, TFT.RED)

            last_Gx, last_Gy = Gx, Gy

        print("X:{:.2f}  Y:{:.2f}  Z:{:.2f}".format(gx,gy,gz))
        utime.sleep_ms(500)
    pass

if __name__ == "__main__":
    main()
