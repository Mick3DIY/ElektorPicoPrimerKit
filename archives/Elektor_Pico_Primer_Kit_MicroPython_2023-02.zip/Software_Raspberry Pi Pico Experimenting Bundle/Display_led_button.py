#----------------------------------------------------------------
#			CONTROLLING LEDs VIA BUTTONS
#			============================
#
# Author: Dogan Ibrahim
# File  : Display_led_button.py
# Date  : March 2022
#
# Note: This program has been taken from the Makerfabs web
# site and has been modified slightly for the book
#------------------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin
import utime
import math

#
# Initialize SPI
#
spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=None)
tft = TFT(spi, 14, 15, 13)

#
# Configure the buzzer, LEDs, and buttons
#
buzzer = machine.Pin(4, machine.Pin.OUT)
YLED = machine.Pin(18, machine.Pin.OUT)
GLED = machine.Pin(19, machine.Pin.OUT)
BLED = machine.Pin(20, machine.Pin.OUT)

button_1 = machine.Pin(2, machine.Pin.IN, machine.Pin.PULL_UP)
button_2 = machine.Pin(3, machine.Pin.IN, machine.Pin.PULL_UP)
button_3 = machine.Pin(22, machine.Pin.IN, machine.Pin.PULL_UP)

param_list = ["Button1", "Button2", "Button3", "YLED", "GLED", "BLED"]
state_list = [0, 0, 0, 1, 1, 1]
flag = 1
buzzer.value(0)

#
# Screen update and control leds
#
def display_state():
    tft.fillrect((60, 15), (128, 128), TFT.BLACK)
    YLED.value(state_list[0])
    GLED.value(state_list[1])
    BLED.value(state_list[2])

    for i in range(6):
        if state_list[i] == 0:
            tft.text((60, i * 15 + 15), "OFF",
                     TFT.WHITE, sysfont, 1, nowrap=True)
        else:
            tft.text((60, i * 15 + 15), "ON", TFT.RED, sysfont, 1, nowrap=True)

#
# Read button values and return 1 if a button pressed
#
def read_button():
    if button_1.value() == 0:
        state_list[0] = not state_list[0]
        state_list[3] = not state_list[3]
        return 1

    if button_2.value() == 0:
        state_list[1] = not state_list[1]
        state_list[4] = not state_list[4]
        return 1

    if button_3.value() == 0:
        state_list[2] = not state_list[2]
        state_list[5] = not state_list[5]
        return 1
    return 0

#
# Main program. Display heading, and static data. Check if
# any button is pressed and update the button state and the
# LED state
#
tft.initg()
tft.rgb(True)
tft.fill(TFT.BLACK)
tft.text((0, 0), "Display_led_button", TFT.WHITE, sysfont, 1, nowrap=True)

for i in range(6):
    tft.text((0, i * 15 + 15),
    param_list[i], TFT.WHITE, sysfont, 1, nowrap=True)

display_state()
while True:
    if read_button() == 1:              # Button pressed
        buzzer.value(1)                 # Buzzer ON
        utime.sleep_ms(500)             # Wait a while
        buzzer.value(0)                 # Buzzer OFF
        display_state()                 # Display state
        utime.sleep_ms(500)             # Wait a while

