#---------------------------------------------------------
#		PUSHBUTTON CONTROL
#		==================
#
# In this program the on-board yellow LED and pushbutton K1
# are used. Pressing the Button turns ON the LED
#
# Author: Dogan Ibrahim
# File  : ButtonLED.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import time

ButtonK1=Pin(2,Pin.IN)   		# Button K1 at GP2
YLED=Pin(18,Pin.OUT)                	# Yellow LED at GP18
YLED.value(1)                       	# LED OFF at beginning

try:
    while True:
        if(ButtonK1.value() == 0):  	# Button pressed
            YLED.value(0)            	# LED ON
        else:
            YLED.value(1)            	# LED OFF

except KeyboardInterrupt:
    pass





    