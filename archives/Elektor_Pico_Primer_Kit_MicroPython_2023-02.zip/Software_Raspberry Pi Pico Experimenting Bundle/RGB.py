#==========================================================
#                WS2812 8-LED RING
#                ==================
#
# In this project the WS2812 8-LED RGB ring is connected
# to the development board. The LEDs are turned ON ann OFF
# in various forms to make it visually attractive
#
# Author: Dogan Ibrahim
# FIle  : RGB
# Date  : March, 2022
#===========================================================
import machine, neopixel
import utime

n = 8                                         # No of LEDs
np = neopixel.NeoPixel(machine.Pin(16), n)    # At GP16

#
# This is the demo function. np[i] = (r, g, b) colours.
#
def demo(np):
    #
    # Circular effect.One pixel runs through all strip positions
    # while the others are closed. Write and wait 25 ms
    #
    for i in range(4 * n):
        for j in range(n):
            np[j] = (0, 0, 0)                  # All cleared
        np[i % n] = (255, 255, 255)            # All White initially
        np.write()
        utime.sleep_ms(25)
    #
    # Rebound effect and set colour (R,G,B).Write and wait 60 ms
    #
    for i in range(4 * n):
        for j in range(n):
            np[j] = (0, 0, 128)
        if (i // n) % 2 == 0:
            np[i % n] = (0, 0, 0)
        else:
                np[n - 1 - (i % n)] = (0, 0, 0)
        np.write()
        utime.sleep_ms(60)

while True:
        demo(np)
