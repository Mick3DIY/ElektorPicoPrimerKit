#---------------------------------------------------------------
#				PARKING AID
#				===========
#
# This project helps to park a car by detecting the obstacles
# and sounding the buzzer accordingly. The ultrasonic module
# should be mounted at the front or rear of the car. As the
# car gets nearer the object, the buzzer sounds faster to
# warn the driver
#
# Author: Dogan Ibrahim
# File  : Parking.py
# Date  : March, 2022
#----------------------------------------------------------------
import utime
#import os
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=None)

tft = TFT(spi, 14, 15, 13)
trigger = Pin(16, Pin.OUT)
echo = Pin(17, Pin.IN)

Buzzer = Pin(4, Pin.OUT)                # Buzzer at pin 18
Buzzer.value(0)                         # Turn OFF buzzer

#
# Calculate and return the distance to the object
#
def ultra():
    trigger.low()                        # Trigger 0
    utime.sleep_us(2)
    trigger.high()                       # Send trigger
    utime.sleep_us(5)                    # Wait 5us
    trigger.low()                        # Trigger 0

    while echo.value() == 0:             # Echo 0
        signaloff = utime.ticks_us()

    while echo.value() == 1:             # Echo 1
        signalon = utime.ticks_us()
        
    timepassed = signalon - signaloff    # Elapsed time
    distance = (timepassed * 0.0343) / 2
    
    return distance


#
# Call ultra to calculate the distance, then display on TFT
#
def main():
    tft.initg()
    tft.rgb(True)
    tft.fill(TFT.BLACK)
    
    tft.text((10, 10), "Parking", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.text((0, 30), "Distance:", TFT.YELLOW, sysfont, 2, nowrap=True)

    while True:
        utime.sleep(0.1)

        tft.fillrect((0, 50), (128, 128), TFT.BLACK)
        dist = ultra()
        tft.text((0, 50), "{} cm".format(dist), TFT.YELLOW, sysfont, 2, nowrap=True)
#
# Now sound the buzzer accordingly.The sounding should be faster
# as the car gets neareer the object.This is done by changing the
# delay in the duration of the sound
#

        if dist > 100:
            dely = 0
        elif dist > 70 and dist < 90:
            dely = 600
        elif dist > 50 and dist < 70:
            dely = 400
        elif dist > 30 and dist < 50:
            dely = 300
        elif dist > 10 and dist < 30:
            dely = 200
        elif dist < 10:
            dely = 10
       
        if dist < 100:
            Buzzer.value(1)
            utime.sleep_ms(dely)
            Buzzer.value(0)
            utime.sleep_ms(dely)

if __name__ == "__main__":
    main()
