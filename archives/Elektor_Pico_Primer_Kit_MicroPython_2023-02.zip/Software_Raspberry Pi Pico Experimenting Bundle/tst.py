#----------------------------------------------------------
#		SEND TEMPERATURE TO SMART PHONE
#		===============================
#
# In this project the ESP-12S module is connected to the Raspberry
# Pi Pico. Also, the MPU6050 is connected. The temperature
# is read from the MPU6050 and sent to smart phone
#
# Author: Dogan Ibrahim
# File  : Temptowifi.py
# Date  : March 2022
#------------------------------------------------------------
from machine import Pin, UART
import utime
from imu import MPU6050
from machine import Pin, I2C

uart = UART(0, baudrate=115200,rx=Pin(1),tx=Pin(0))
i2c = I2C(0, sda=Pin(8), scl=Pin(9), freq=400000)
imu = MPU6050(i2c)

#
# Send
#
#
# This function sends AT command, terminated with \r\n
#
def sendAT(uart, str):
    str += "\r\n"
    uart.write(str)
    utime.sleep(3)
    while uart.any():
        print(uart.readline())
    utime.sleep(3)
    while uart.any():
        print(uart.readline())

#
# Send command and wait for response
#
def sendCMD_waitRespLine(cmd, timeout=3000):
    print("CMD: " + cmd)
    cmd += "\r\n"
    uart.write(cmd)
    waitRespLine(timeout)
    print()
    
#
# Wait for response with timeout
#
def waitRespLine(timeout=4000):
    prvMills = utime.ticks_ms()
    while (utime.ticks_ms()-prvMills)<timeout:
        if uart.any():
            print(uart.readline().decode('utf8'))
            
#
# Disable echo and connect to local Wi-fi router
#
sendCMD_waitRespLine("ATE0")
sendCMD_waitRespLine("AT+CWMODE=1")
sendCMD_waitRespLine("AT+CWJAP=\"BTHomeSpot-XNH\",\"49345abaeb\"" ,timeout = 10000)

#
# Establish UDP connection at port 5000
#
sendCMD_waitRespLine("AT+CIPMUX=0")
sendCMD_waitRespLine("AT+CIPSTART=\"UDP\",\"192.168.1.219\",5000,5000,0")

#
# Main program loop. Send the temperature to smart phone
#
while True:
     buf = uart.readline()					# Read data
     if buf:
       print("buf=")
       print(buf)
       dat = buf.decode('UTF-8')				# Decode
       n = dat.find("T?")						# T? received?
       if n > 0:
            T = imu.temperature
            Tstr = "T=" + str(T)				# Insert T=
            print("Tstr=")
            print(Tstr)
            Tlen = str(len(Tstr))				# Length
            print("Tlen=")
            print(Tlen)
            Dt = "AT+CIPSEND="+Tlen + "\r" + "\n"
            print("Dt")
            print(Dt)   # AT command to send
            uart.write(Dt)						# Send to ESP-01
            utime.sleep(4)						# Wait 2 sec
            uart.write(Tstr)					# Send data
            utime.sleep(2)
            sendCMD_waitRespLine("AT+CIPCLOSE")
            utime.sleep(2)
            sendCMD_waitRespLine("AT+CIPSTART=\"UDP\",\"192.168.1.219\",5000,5000,0")
       utime.sleep(2)
         
     
     