#---------------------------------------------------------
#		CONNECT TO LOCAL WI-FI ROUTER
#		=============================
#
# This program shows hot to connect to the local Wi-Fi
#
# Author: Dogan Ibrahim
# File  : test_at.py
# Date  : March, 2022
#
# Note: This program has been taken from the Makerfabs web
# site and has been modified for the book
#----------------------------------------------------------
import os
import utime
import machine

#
# This function sends AT command, terminated with \r\n
#
def sendAT(uart, str):
    str += "\r\n"
    uart.write(str)
    utime.sleep(3)
    while uart.any():
        print(uart.readline())
    utime.sleep(3)
    while uart.any():
        print(uart.readline())

#
# Send command and wait for response
#
def sendCMD_waitRespLine(cmd, timeout=2000):
    print("CMD: " + cmd)
    cmd += "\r\n"
    uart.write(cmd)
    waitRespLine(timeout)
    print()
    
#
# Wait for response with timeout
#
def waitRespLine(timeout=4000):
    prvMills = utime.ticks_ms()
    while (utime.ticks_ms()-prvMills)<timeout:
        if uart.any():
            print(uart.readline().decode('utf8'))

#
# Start of main program. Print system and uart info
#
print(os.uname())
uart = machine.UART(0)
print(uart)

#
# Get version number and turn echo OFF
#
sendCMD_waitRespLine("AT+GMR")
sendCMD_waitRespLine("ATE0")

# Connect to local Wi-fi router
sendCMD_waitRespLine("AT+CWMODE=1")
sendCMD_waitRespLine("AT+CWJAP=\"BTHomeSpot-XNH\",\"49345xxx\"" ,timeout = 10000)

sendCMD_waitRespLine("AT+CIFSR")
sendCMD_waitRespLine("AT+PING=\"www.bbc.co.uk\"",timeout = 10000)

print()
print("Over")

