#---------------------------------------------------------------
#		ULTRASONIC DISTANCE MEASUREMENT
#		==============================
#
# In this project the HC-SR04 ultrasonic transmiter-receiver
# pair is used to measure the distance to an object
# in-front of the sensor module. The distance is displayed
# on the TFT display in cm
#
# Author: Dogan Ibrahim
# File  : HC-SR04_distance.py
# Date  : March, 2022
#
# Note: This program has been taken from the Makerfabs web
# site and has been modified slightly for the book
#----------------------------------------------------------------
import utime
import os
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=None)

tft = TFT(spi, 14, 15, 13)
trigger = Pin(16, Pin.OUT)
echo = Pin(17, Pin.IN)

#
# Calculate and return the distance to the object in cm
#
def ultra():
    trigger.low()                        # Trigger 0
    utime.sleep_us(2)
    trigger.high()                       # Send trigger
    utime.sleep_us(5)                    # Wait 5us
    trigger.low()                        # Trigger 0

    while echo.value() == 0:             # Echo 0
        signaloff = utime.ticks_us()

    while echo.value() == 1:             # Echo 1
        signalon = utime.ticks_us()
        
    timepassed = signalon - signaloff    # Elapsed time
    distance = (timepassed * 0.0343) / 2
    
    return distance


#
# Call ultra to calculate the distance,then display on TFT
#
def main():
    tft.initg()
    tft.rgb(True)
    tft.fill(TFT.BLACK)
    
    tft.text((10, 10), "Ultra Distance", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.text((0, 30), "Distance:", TFT.YELLOW, sysfont, 2, nowrap=True)

    while True:
        utime.sleep(0.3)

        tft.fillrect((0, 50), (128, 128), TFT.BLACK)
        tft.text((0, 50), "{} cm".format(ultra()), TFT.YELLOW, sysfont, 2, nowrap=True)


if __name__ == "__main__":
    main()
