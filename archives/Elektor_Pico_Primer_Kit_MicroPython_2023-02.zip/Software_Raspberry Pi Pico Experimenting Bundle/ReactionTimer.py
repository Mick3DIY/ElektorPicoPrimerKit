#----------------------------------------------------------------
#				REACTION TIMER
#				==============
#
# This is a reaction timer program which measures the reaction
# of the user and displays on the TFT display in ms. For a
# fast reaction time, the user should press the pushbutton as 
# soon as the LED is lit
#
# Author: Dogan Ibrahim
# File  : TFTReaction.py
# Date  : October 2022
#------------------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin
import utime
import random

spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
sck=Pin(2), mosi=Pin(3), miso=Pin(4))

#
# Button and LED configuration
#
Button = Pin(16, Pin.IN)					# Pushbutton
LED = Pin(17, Pin.OUT)					    # LED
flag = 0

tft = TFT(spi, 15, 14, 5)
tft.initg()
tft.rgb(True)

#
# This is the interrupt service routine. The program jumps here
# as soon as the pushbutton is pressed
#
def MyButton(pin):
    global flag
    Button.irq(handler = None)
    LED.value(1)					        # LED OFF
    TmrEnd = utime.ticks_ms()				# End of time
    ReactionTime = utime.ticks_diff(TmrEnd, TmrStart)
    flag = 1
    tft.text((20, 60), "Time:{:.2f} ms".format(ReactionTime), TFT.WHITE, 
    sysfont, 1, nowrap=True)
    utime.sleep(3)

#
# Display heading
#
def Heading():
   tft.fill(TFT.BLACK)						# Clear screen
   tft.rect((10, 10), (115, 100), TFT.WHITE)
   tft.text((19, 40), "REACTION TIMER", TFT.WHITE, sysfont, 
   1.1, nowrap=True)

#
# Start of MAIN program. Generate a random delay and then turn ON LED
#
LED.value(1)					        # LED OFF

while True:					            # DO FOREVER
    Heading()
    flag = 0
    rnd = random.randint(3, 10)			# Random integer number
    utime.sleep(rnd)				    # Delay random
    LED.value(0)				        # LED ON
    TmrStart = utime.ticks_ms()
    Button.irq(handler=MyButton, trigger = Pin.IRQ_FALLING)
    while flag == 0:
       pass


   
  










