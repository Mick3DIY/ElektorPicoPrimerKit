#---------------------------------------------------------------
#				STADIOMETER
#				===========
#
# This is a stadiometer project which measures the height
# of a person. The project consists of an ultrasonic module
#and a frame as shown in the text. The person whose height is
# to be measured stands under the sensor. The program
# calculates the distance from teh sensor to the head of
# the person and then calculates the height of the person.
#
# Author: Dogan Ibrahim
# File  : Stadiometer.py
# Date  : March, 2022
#----------------------------------------------------------------
import utime
import os
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=None)

tft = TFT(spi, 14, 15, 13)
trigger = Pin(16, Pin.OUT)
echo = Pin(17, Pin.IN)
H = 200									# Height=200cm

#
# Calculate and return the distance to the head of person
#
def ultra():
    trigger.low()                        # Trigger 0
    utime.sleep_us(2)
    trigger.high()                       # Send trigger
    utime.sleep_us(5)                    # Wait 5us
    trigger.low()                        # Trigger 0

    while echo.value() == 0:             # Echo 0
        signaloff = utime.ticks_us()

    while echo.value() == 1:             # Echo 1
        signalon = utime.ticks_us()
        
    timepassed = signalon - signaloff    # Elapsed time
    distance = (timepassed * 0.0343) / 2
    
    return distance


#
# Call ultra to calculate the height, then display on TFT
#
def main():
    tft.initg()
    tft.rgb(True)
    tft.fill(TFT.BLACK)
    
    tft.text((10, 10), "Stadiometer", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.text((0, 30), "Height:", TFT.YELLOW, sysfont, 2, nowrap=True)

    while True:
        utime.sleep(0.3)

        tft.fillrect((0, 50), (128, 128), TFT.BLACK)
        height = H - ultra()
        tft.text((0, 50), "{} cm".format(height), TFT.YELLOW, sysfont, 2, nowrap=True)


if __name__ == "__main__":
    main()
