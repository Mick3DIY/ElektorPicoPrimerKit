#---------------------------------------------------------
#		TEMPERATURE DISPLAY ON SCREEN
#		=============================
#
# In this program the DHT11 temperature and humidity
# sensor is used and the ambient temperature is displayed
# on the Thonny screen every 5 seconds
#
# Author: Dogan Ibrahim
# File  : temperature_screen.py
# Date  : March, 2022
#----------------------------------------------------------
import utime as time
from dht import DHT11
from machine import Pin

#
# Read the ambient temperature and humidity and display on
# the Thonny screen every 5 seconds
#
while True:
    pin = Pin(16, Pin.OUT, Pin.PULL_DOWN)
    sensor = DHT11(pin)
    sensor.measure()
    t  = sensor.temperature()
    h = sensor.humidity()

    print("Temperature: {}C".format(t))
    print("   Humidity: {}%\n".format(h))
    time.sleep(5)
    