#----------------------------------------------------------
#		DISPLAY A BITMAP IMAGE
#		======================
#
# In this program heart images are displayed across the OLED
#
# Author: Dogan Ibrahim
# File  : OLEDheart.py
# Date  : January, 2022
#------------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

tft.fill(TFT.BLACK)				# Clear screen

#
# Heart shape bitmap
#
HEART = [
[ 0, 0, 0, 0, 0, 0, 0, 0, 0],
[ 0, 1, 1, 0, 0, 0, 1, 1, 0],
[ 1, 1, 1, 1, 0, 1, 1, 1, 1],
[ 1, 1, 1, 1, 1, 1, 1, 1, 1],
[ 1, 1, 1, 1, 1, 1, 1, 1, 1],
[ 0, 1, 1, 1, 1, 1, 1, 1, 0],
[ 0, 0, 1, 1, 1, 1, 1, 0, 0],
[ 0, 0, 0, 1, 1, 1, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
]

ARROW = [
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 1, 1, 1, 0, 0, 0],
[ 0, 0, 1, 0, 1, 0, 1, 0, 0],
[ 0, 1, 0, 0, 1, 0, 0, 1, 0],
[ 1, 0, 0, 0, 1, 0, 0, 0, 1],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
]

#
# Clear and display 6 heart shapes across the display
#
  
for i in range(0, 120, 20):
 for y, row in enumerate(ARROW):
    for x, c in enumerate(row):
        if c == 1:
           tft.pixel((x+i, y+30), TFT.WHITE)
        else:
           tft.pixel((x+i, y+30), TFT.BLACK)


