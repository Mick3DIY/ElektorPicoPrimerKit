#----------------------------------------------------------
#		           REMOTE LED CONTROL
#		           ==================
#
# In this project the yellow LED on the development board
# is controlled from a smartphone using Wi-Fi. Command
# LON turns ON the LED, and command LOFF turns OFF the LED
#
# Author: Dogan Ibrahim
# File  : Picowifi.py
# Date  : March 2022
#------------------------------------------------------------
from machine import Pin, UART
import utime
import os
import machine
uart = UART(0, baudrate=115200,rx=Pin(1),tx=Pin(0))

YLED = Pin(18, Pin.OUT)               # Yellow LED
YLED.value(1)                         # LED OFF

#
# This function sends AT command, terminated with \r\n
#
def sendAT(uart, str):
    str += "\r\n"
    uart.write(str)
    utime.sleep(3)
    while uart.any():
        print(uart.readline())
    utime.sleep(3)
    while uart.any():
        print(uart.readline())

#
# Send command and wait for response
#
def sendCMD_waitRespLine(cmd, timeout=2000):
    print("CMD: " + cmd)
    cmd += "\r\n"
    uart.write(cmd)
    waitRespLine(timeout)
    print()
    
#
# Wait for response with timeout
#
def waitRespLine(timeout=4000):
    prvMills = utime.ticks_ms()
    while (utime.ticks_ms()-prvMills)<timeout:
        if uart.any():
            print(uart.readline().decode('utf8'))
            
#
# Disable echo and connect to local Wi-fi router
#
sendCMD_waitRespLine("ATE0")
sendCMD_waitRespLine("AT+CWMODE=1")
sendCMD_waitRespLine("AT+CWJAP=\"BTHomeSpot-XNH\",\"49345abaeb\"" ,timeout = 10000)

#
# Establish UDP connection at port 5000
#
sendCMD_waitRespLine("AT+CIPMUX=0")
sendCMD_waitRespLine('''AT+CIPSTART="UDP","0.0.0.0",5000,5000,2\r\n''')

#
# Main program loop. Read the received data from the netwok
# Decode the data and control the LED accordingly
#
while True:
     buf = uart.readline()					# Read data
     if buf:
        dat = buf.decode('UTF-8')			# Decode
        print(dat)
        n = dat.find("LON")					# Includes LON?
        if n > 0:
           YLED.value(0)					# LED ON
        n = dat.find("LOFF")				# Includes OFF?
        if n > 0:
           YLED.value(1)					# LED OFF

     




    
    


      