#---------------------------------------------------------
#			LED FLASHING SOS
#			================
#
# In this program the external LED at port GP1 flashes the
# SOS signal (... --- ...)
#
# Author: Dogan Ibrahim
# File  : SOS.py
# Date  : October, 2022
#----------------------------------------------------------
from machine import Pin
import utime

Dot = 0.25                      # Dot time
Dash = 1.0                      # Dash time
Gap = 0.2                       # Gap time
ON = 1                          # ON
OFF = 0                         # OFF

LED = Pin(1, Pin.OUT)		    # LED at GP1

while True:			            # DO FOREVER
    for i in range(0, 3):
        LED.value(ON)           # LED ON
        utime.sleep(Dot)        # Wait Dot time
        LED.value(OFF)          # LED OFF
        utime.sleep(Gap)        # Wait Gap time
        
    utime.sleep(0.5)            # 0.5 second delay
    
    for i in range(0, 3):
        LED.value(ON)           # LED ON
        utime.sleep(Dash)       # Wait Dash time
        LED.value(OFF)          # LED OFF
        utime.sleep(Gap)       # Wait Gap time
        
    utime.sleep(0.5)		    # 0.5 second delay
        
    for i in range(0, 3):
        LED.value(ON)           # LED ON
        utime.sleep(Dot)        # Wait Dot time
        LED.value(OFF)          # LED OFF
        utime.sleep(Gap)        # Wait Gap time
    
    utime.sleep(2)              # Wait 2 seconds


