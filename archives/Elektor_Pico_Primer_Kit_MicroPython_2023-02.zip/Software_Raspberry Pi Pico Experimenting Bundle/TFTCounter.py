#-----------------------------------------------------
#	  	SECONDS COUNTER
#	  	===============
#
# This is a seconds counter program. The program counts
# up every second. Counting starts when button at GP16
# is pressed
#
# Author: Dogan Ibrahim
# File  : SecondsCounter.py
# Date  : October, 2022
#------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin
import utime

spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
sck=Pin(2), mosi=Pin(3), miso=Pin(4))

Button=Pin(16,Pin.IN, Pin.PULL_UP)      # Button at GP16
tft = TFT(spi, 15, 14, 5)
tft.initg()
tft.rgb(True)

tft.fill(TFT.BLACK)						# Clear screen
Count = 0

#
# Display heading
#
tft.rect((10, 10), (110, 100), TFT.WHITE)
tft.text((15, 40), "SECONDS COUNTER", TFT.WHITE, sysfont, 
1.1, nowrap=True)

while Button.value() == 1:			    # Wait for button
   pass

#
# Increment Count every second and display on the TFT
#
while True:
  tft.text((20, 60), "Count:{:d}".format(Count), TFT.WHITE, 
  sysfont, 1, nowrap=True)
  Count = Count + 1
  utime.sleep(1)
  










