#----------------------------------------------
#	  	AREAS OF SHAPES
#	  	===============
#
# This program calculates and displays the areas
# of various geometrical shapes
# of numbers in a list
#
# Author: Dogan Ibrahim
# File  : areas.py
# Date  : March, 2022
#----------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(1, baudrate=20000000, polarity=0, phase=0, sck=Pin(10), mosi=Pin(11),
miso=None)

tft = TFT(spi, 14, 15, 13)

tft.rect((0, 0), (50, 50), tft.GREEN)







