#---------------------------------------------------------
#			BUZZER SOUNDING SOS
#			===================
#
# In this program the buzzer sounds the SOS signal
#
# Author: Dogan Ibrahim
# File  : SOSBuzzer.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime

Dot = 0.25                      # Dot time
Dash = 1.0                      # Dash time
Gap = 0.2                       # Gap time
ON = 1                          # ON
OFF = 0                         # OFF

Buzzer = Pin(4, Pin.OUT)	    # Buzzer at GP4

while True:			            # DO FOREVER
    for i in range(0, 3):
        Buzzer.value(ON)        # Buzzer ON
        utime.sleep(Dot)        # Wait Dot time
        Buzzer.value(OFF)       # Buzzer OFF
        utime.sleep(Gap)        # Wait Gap time
        
    utime.sleep(0.5)            # 0.5 second delay
    
    for i in range(0, 3):
        Buzzer.value(ON)        # Buzzer ON
        utime.sleep(Dash)       # Wait Dash time
        Buzzer.value(OFF)       # Buzzer OFF
        utime.sleep(Gap)        # Wait Gap time
        
    utime.sleep(0.5)		    # 0.5 second delay
        
    for i in range(0, 3):
        Buzzer.value(ON)        # Buzzer ON
        utime.sleep(Dot)        # Wait Dot time
        Buzzer.value(OFF)       # Buzzer OFF
        utime.sleep(Gap)        # Wait Gap time
    
    utime.sleep(2)              # Wait 2 seconds


