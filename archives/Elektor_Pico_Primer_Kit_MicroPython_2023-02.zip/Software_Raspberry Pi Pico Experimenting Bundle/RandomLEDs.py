#---------------------------------------------------------
#		RANDOMLY FLASHING 3 LEDs
#		=========================
#
# In this program the on-board yellow, green, and blue LEDs
# flash randomly.
#
# Author: Dogan Ibrahim
# File  : RandomLEDs.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime
import random

Yellow = Pin(18, Pin.OUT)		# Yellow LED
Green = Pin(19, Pin.OUT)		# Green LED
Blue = Pin(20, Pin.OUT)			# Blue LED

while True:
    y = random.randint(0, 1)
    g = random.randint(0, 1)
    b = random.randint(0, 1)
    Yellow.value(y)
    utime.sleep(0.2)
    Green.value(g)
    utime.sleep(0.2)
    Blue.value(b)
    utime.sleep(0.2)
