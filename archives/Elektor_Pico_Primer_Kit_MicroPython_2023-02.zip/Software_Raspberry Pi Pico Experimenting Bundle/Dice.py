#----------------------------------------------
#	  	DOUBLE DICE
#	  	===========
#
# This program displays two random dice numbers
# between 1 and 6 when the Enter key is pressed
#
# Author: Dogan Ibrahim
# File  : dice.py
# Date  : July, 2019
#----------------------------------------------
import random
strt = 'a'

while strt.upper() != 'X':
  strt = input("Pres ENTER to start, X to exit ")
  first = random.randint(1, 6)
  second = random.randint(1, 6)
  print("%d   %d" %(first, second))





