#----------------------------------------------------------
#		DISPLAY BITMAP IMAGES
#		======================
#
# In this program heart images and arrow images are displayed
# across the TFT screen with 20 pixels space between each shape
#
# Author: Dogan Ibrahim
# File  : bitmaps.py
# Date  : October, 2022
#------------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

#
# Initialize the SPI bus for the TFT
#
spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
sck=Pin(2), mosi=Pin(3), miso=Pin(4))

tft = TFT(spi, 15, 14, 5)
tft.initg()
tft.rgb(True)

tft.fill(TFT.BLACK)				# Clear screen

#
# Heart shape bitmap
#
HEART = [
[ 0, 0, 0, 0, 0, 0, 0, 0, 0],
[ 0, 1, 1, 0, 0, 0, 1, 1, 0],
[ 1, 1, 1, 1, 0, 1, 1, 1, 1],
[ 1, 1, 1, 1, 1, 1, 1, 1, 1],
[ 1, 1, 1, 1, 1, 1, 1, 1, 1],
[ 0, 1, 1, 1, 1, 1, 1, 1, 0],
[ 0, 0, 1, 1, 1, 1, 1, 0, 0],
[ 0, 0, 0, 1, 1, 1, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
]

#
# Arrow shape bitmap
#
ARROW = [
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 1, 1, 1, 0, 0, 0],
[ 0, 0, 1, 0, 1, 0, 1, 0, 0],
[ 0, 1, 0, 0, 1, 0, 0, 1, 0],
[ 1, 0, 0, 0, 1, 0, 0, 0, 1],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
[ 0, 0, 0, 0, 1, 0, 0, 0, 0],
]

#
# Clear and display 6 shapes across the display
#
  
for i in range(0, 120, 20):
 for y, row in enumerate(HEART):
    for x, c in enumerate(row):
        if c == 1:
           tft.pixel((x+i, y+30), TFT.WHITE)
        else:
           tft.pixel((x+i, y+30), TFT.BLACK)


