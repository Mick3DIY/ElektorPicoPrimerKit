#---------------------------------------------------------
#		TEMPERATURE DISPLAY ON LED
#		==========================
#
# In this program the DHT11 temperature and humidity
# sensor is used. If the ambient temperature is below
# a lower limit then the blue LED is turned ON. If the
# temperature is above the upper limit then the yellow
# LED is turned ON
#
# Author: Dogan Ibrahim
# File  : temperature_LED.py
# Date  : March, 2022
#----------------------------------------------------------
import utime
from dht import DHT11
from machine import Pin

Upper = 30						# Upper temp limit
Lower = 25						# Lower temp limit
OFF = 1
ON = 0

#
# YLED and BLED are outputs
#
YLED = Pin(18, Pin.OUT)			# Yellow LED
GLED = Pin(19, Pin.OUT)			# Green LED (not used)
BLED = Pin(20, Pin.OUT)			# Blue LED
YLED.value(1)					# YLED OFF
GLED.value(1)					# GLED OFF
BLED.value(1)					# BLED OFF

#
# Read the ambient temperature and humidity and display on
# the Thonny screen every 5 seconds
#
while True:
    pin = Pin(16, Pin.OUT, Pin.PULL_DOWN)
    sensor = DHT11(pin)
    sensor.measure()
    t  = sensor.temperature()
    
    if t < Lower:				# Temp low
       YLED.value(OFF)			# YLED OFF
       BLED.value(ON)			# BLED ON
    elif t > Upper:				# Temp high
       BLED.value(OFF)			# BLED OFF
       YLED.value(ON)			# YLED ON
       
    utime.sleep(2)

  
    