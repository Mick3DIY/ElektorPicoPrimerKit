#---------------------------------------------------------
#		LED FLASHING USING A TIMER
#		==========================
#
# In this program an external LED flashes twice a second
# using a timer
#
# Author: Dogan Ibrahim
# File  : LEDTimer.py
# Date  : October, 2022
#----------------------------------------------------------
from machine import Pin, Timer

LED = Pin(1, Pin.OUT)
tim = Timer()

def Flash_LED(timer):
    global LED
    LED.toggle()

tim.init(freq = 2.0, mode = Timer.PERIODIC, callback = Flash_LED)
