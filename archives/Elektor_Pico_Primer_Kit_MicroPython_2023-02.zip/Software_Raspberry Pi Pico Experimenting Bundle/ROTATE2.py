#---------------------------------------------------------
#		ROTATING LEDs
#		=============
#
# In this program 3 LEDs are rotated to give the effect of
# chasing each other
#
# Author: Dogan Ibrahim
# File  : Rotate2.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime

LEDS = [20, 19, 18]			# LED ports
L = [0, 0, 0]

for i in range(3):			# Do for all LEDs
    L[i] = Pin(LEDS[i], Pin.OUT)	# All are outputs

while True:				# Do forever
    for i in range(3):
        L[i].value(0)			# LED ON
        utime.sleep(0.5)		# Wait 0.5 second
        L[i].value(1)			# LED OFF
                