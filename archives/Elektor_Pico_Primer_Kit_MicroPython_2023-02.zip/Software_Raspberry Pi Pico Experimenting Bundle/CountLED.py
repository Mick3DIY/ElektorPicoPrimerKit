#---------------------------------------------------------
#			BINARY COUNTING 3 LEDs
#			======================
#
# In this program the on-board yellow, green, and blue LEDs
# count up in binary from 0 to 7
#
# Author: Dogan Ibrahim
# File  : CountLED.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime

YLED = Pin(18, Pin.OUT)				# Yellow LED
GLED = Pin(19, Pin.OUT)				# Green LED
BLED = Pin(20, Pin.OUT)				# Blue LED


while True:
   BLED.value(1)				# Yellow OFF
   GLED.value(1)				# Green OFF
   YLED.value(1)				# Blue OFF
   utime.sleep(1)

   BLED.value(0)				# Blue ON
   utime.sleep(1)

   BLED.value(1)				# Blue OFF
   GLED.value(0)				# Green ON
   utime.sleep(1)

   BLED.value(0)				# Blue ON
   utime.sleep(1)

   BLED.value(1)				# Blue OFF
   GLED.value(1)				# Green OFF
   YLED.value(0)				# Yellow ON
   utime.sleep(1)

   BLED.value(0)				# Blue ON
   utime.sleep(1)

   BLED.value(1)				# Blue OFF
   GLED.value(0)				# Green ON
   utime.sleep(1)

   BLED.value(0)				# Blue ON
   utime.sleep(1)




     