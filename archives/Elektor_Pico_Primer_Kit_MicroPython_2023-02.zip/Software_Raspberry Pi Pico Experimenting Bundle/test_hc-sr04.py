#---------------------------------------------------------------
#		ULTRAONIC DISTANCE MEASUREMENT
#		==============================
#
# In this project the HC-SR04 ultrasonic transmiter-receiver
# pair is used to measure the distance to an object
# in-front of the sensor module. The distance is dislayed
# on the Thonny screen in cm
#
# Author: Dogan Ibrahim
# File  : test_hc-sr04.py
# Date  : February, 2022
#
# Note: This program has beentaken from the Makerfabs web
# site and has been modified slightly for the book
#----------------------------------------------------------------
from machine import Pin
import utime

trigger = Pin(16, Pin.OUT)                 # Trig pin
echo = Pin(17, Pin.IN)                     # Echo pin

#
# Function to read the distance
#
def ultra():
    print("\nstart")
    trigger.low()
    utime.sleep_us(2)
    trigger.high()                         # Send trigger
    utime.sleep_us(5)                      # ...For 5 us
    trigger.low()
    
    while echo.value() == 0:               # Check Echo for 0
        signaloff = utime.ticks_us()
    
    while echo.value() == 1:               # Check Echo for 1
        signalon = utime.ticks_us()
    
    timepassed = signalon - signaloff      # Elapsed time
    distance = (timepassed * 0.0343) / 2   # Distance in cm
    print("The distance from object is ", distance, "cm")

#
# Call function ultra to read and display the distance
#
while True:
    ultra()
    utime.sleep(0.5)

