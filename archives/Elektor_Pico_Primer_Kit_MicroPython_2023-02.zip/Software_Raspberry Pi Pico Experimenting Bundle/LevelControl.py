#---------------------------------------------------------------
#				LIQUID LEVEL CONTROLLER
#				=======================
#
# This project controls the level of liquid in a tank. An
# ultrasonic module is used to detect the level of the
# liquid inside the tank. If the level is below Lmin then
# the relay module is activated, which in turns starts a
# pump to draw water to the tank. The relay is deactivated
# when the liquid level reaches to Lmax
#
# Author: Dogan Ibrahim
# File  : LevelControl.py
# Date  : March, 2022
#----------------------------------------------------------------
import utime
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=None)

tft = TFT(spi, 14, 15, 13)
trigger = Pin(16, Pin.OUT)              # Trig at GP16
echo = Pin(17, Pin.IN)                  # Echo at GP17

#
# Tank requirements and relay configuration
#
Lmin = 30                                # Min 30cm
Lmax = 150                               # Max 150cm
H = 200                                  # H is 200cm
Relay = Pin(26, Pin.OUT)                 # Relay at GP26
Relay.value(0)                           # Relay OFF

#
# Calculate and return the distance to top of water level (d)
#
def ultra():
    trigger.low()                        # Trigger 0
    utime.sleep_us(2)
    trigger.high()                       # Send trigger
    utime.sleep_us(5)                    # Wait 5us
    trigger.low()                        # Trigger 0

    while echo.value() == 0:             # Echo 0
        signaloff = utime.ticks_us()

    while echo.value() == 1:             # Echo 1
        signalon = utime.ticks_us()
        
    timepassed = signalon - signaloff    # Elapsed time
    d = (timepassed * 0.0343) / 2
    
    return d


#
# Call ultra to calculate the distance, then calculte the
# amount of liquid in the tank and activate/deactivate the
# relay accordingly
#
def main():
    tft.initg()
    tft.rgb(True)
    tft.fill(TFT.BLACK)
    
    tft.text((17, 10), "LEVEL CONTROLLER", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.text((5, 30), "Liquid Level:", TFT.YELLOW, sysfont, 1.8, nowrap=True)

    while True:
        utime.sleep(0.5)
        tft.fillrect((0, 50), (128, 128), TFT.BLACK)
        dist = ultra()
        LiquidLevel = H - dist
        tft.text((0, 50), "{} cm".format(LiquidLevel), TFT.RED,
        sysfont, 2, nowrap=True)
        
        if LiquidLevel < Lmin:
            Relay.value(1)                      # Relay ON
        if LiquidLevel > Lmax:
            Relay.value(0)                      # Relay OFF

if __name__ == "__main__":
    main()
