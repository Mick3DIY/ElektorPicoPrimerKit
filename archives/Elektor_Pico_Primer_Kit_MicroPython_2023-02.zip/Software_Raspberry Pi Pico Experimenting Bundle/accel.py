#---------------------------------------------------------
#		ACCELERATION IN 3 AXES
#		======================
#
# This program reads the acceleration from the MPU6050
# module and displays on the thonny screen continuosly
# until stopped by the user
#
# Author: Dogan Ibrahim
# File  : accel.py
# Date  : February, 2022
#----------------------------------------------------------
from imu import MPU6050
import utime
from machine import Pin, I2C
i2c = I2C(0, sda=Pin(8), scl=Pin(9), freq=400000)
imu = MPU6050(i2c)

#
# Read and display the acceleration
#
print("    ACCELERATION")				# Heading
print("    ============")
print("  X\t  Y\t Z")

while True:
  Ax = round(imu.accel.x,2)				# Acc in X
  Ay = round(imu.accel.y,2)				# Acc in Y
  Az = round(imu.accel.z,2)				# Acc in Z
  print(Ax,"\t",Ay,"\t",Az)
  utime.sleep_ms(100)
  

