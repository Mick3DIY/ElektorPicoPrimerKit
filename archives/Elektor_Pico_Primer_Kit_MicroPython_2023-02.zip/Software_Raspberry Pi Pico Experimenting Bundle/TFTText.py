#-----------------------------------------------------
#	  	DISPLAYING TEXT
#	  	===============
#
# This program displays text on the TFT display
#
# Author: Dogan Ibrahim
# File  : TFTText.py
# Date  : October, 2022
#------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
sck=Pin(2), mosi=Pin(3), miso=Pin(4))

tft = TFT(spi, 5, 14, 15)
tft.initg()
tft.rgb(True)

tft.fill(TFT.WHITE)						# Clear screen
tft.text((10, 10), "PICO", TFT.RED, sysfont, 2, nowrap=True)
tft.text((10, 30), "PICO", TFT.GREEN, sysfont, 3, nowrap=True)
tft.text((10, 55), "PICO", TFT.CYAN, sysfont, 4, nowrap=True)
tft.text((10, 90), "PICO", TFT.BLUE, sysfont, 5, nowrap=True)





