#-----------------------------------------------------
#	  	OTHER TFT FUNCTIONS
#	  	===================
#
# This program shows how some other TFT functions are used
#
# Author: Dogan Ibrahim
# File  : TFTOther.py
# Date  : October, 2022
#------------------------------------------------------
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin
import utime

spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
sck=Pin(2), mosi=Pin(3), miso=Pin(4))

tft = TFT(spi, 15, 14, 5)
tft.initg()
tft.rgb(True)

tft.fill(TFT.WHITE)						# Clear screen

tft.text((10, 30), "PICO", TFT.RED, sysfont, 2, nowrap=True)
utime.sleep(2)

tft.rotation(1)							# 90 degrees rotate
tft.text((10, 30), "PICO1", TFT.RED, sysfont, 2, nowrap=True)
utime.sleep(2)

tft.rotation(2)							# 90 degrees rotate
tft.text((10, 50), "PICO2", TFT.RED, sysfont, 2, nowrap=True)
utime.sleep(2)

tft.rotation(3)							# 90 degrees rotate
tft.text((10, 30), "PICO3", TFT.RED, sysfont, 2, nowrap=True)
utime.sleep(2)

tft.rotation(0)							# 90 degrees rotate
tft.text((10, 30), "PICO0", TFT.RED, sysfont, 2, nowrap=True)
utime.sleep(2)













