#---------------------------------------------------------
#		BINARY COUNTING 3 LEDs
#		======================
#
# In this program the on-board yellow, green and blue LEDs are
# used to count up from 0 to 7 every second. The program is
# general and the number of LEDs used can easily be increased.
# (Change 3 to the required port length). The ports can also be
# used as inputs
#
# Author: Dogan Ibrahim
# File  : LEDCount.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime

PORT = [18, 19, 20]			# port connections
DIR = ["0","0","0"]			# port directons
L = [0]*3

#
# This function configures the port pins as outputs ("0") or
# as inputs ("I")
#
def Configure_Port():
   for i in range(0, 3):
      if DIR[i] == "0":
         L[i] = Pin(PORT[i], Pin.OUT)
      else:
         L[i] = Pin(PORT[i], Pin.IN)
   return

#
# This function sends 3-bit data (0 to 7) to the PORT
#
def Port_Output(x):
   b = bin(x)				# convert into binary
   b = b.replace("0b", "")		# remove leading "0b"
   diff = 3 - len(b)			# find the length
   for i in range (0, diff):
      b = "0" + b			# insert leading 0s

   for i in range (0, 3):
      if b[i] == "1":
         L[i].value(0)
      else:
         L[i].value(1)
   return

#
# Configure PORT to all outputs
#
Configure_Port()

#
# Main program loop. Count up in binary every second
#
cnt = 0
while True:
  Port_Output(cnt)				# send cnt to port
  utime.sleep(1)				# wait 1 second
  cnt = cnt + 1					# increment cnt
  if cnt > 7:
     cnt = 0
  


     