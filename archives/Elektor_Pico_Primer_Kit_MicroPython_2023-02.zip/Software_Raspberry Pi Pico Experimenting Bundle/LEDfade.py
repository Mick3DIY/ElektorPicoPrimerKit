#---------------------------------------------------------
#		             FADING LED
#		             ==========
#
# This is a fading LED project. A PWM waveform is generated
# at the yellow LED and the duty cycle is varied. As a
# result the LED brightness changes from bright to dim as
# the duty cycle is changed from 0 to maximum
#
# Author: Dogan Ibrahim
# File  : LEDfade.py
# Date  : March, 2022
#----------------------------------------------------------
import utime
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin, PWM

#
# Initialize the SPI bus
#
spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

ch = PWM(Pin(18))				# PWM at GP18 (YLED)
ch.freq(1000)					# Frequency = 1000Hz
  
i = 0
while True:
    tft.fill(TFT.BLACK)
    tft.text((15, 60), "Duty Cycle:{:2d}".format(i), TFT.WHITE, 
    sysfont, 1, nowrap=True)
    ch.duty_u16(i)				# Change duty cycle
    utime.sleep_ms(300)			# Delay 300ms
    i = i + 5000				# Increment i
    if i > 65535:
        i = 0
