#---------------------------------------------------------
#		MPU6050 TEMPERATURE DISPLAY
#		===========================
#
# In this program the temperature is read using the MPU6050
# module, and is displayed on the TFT display every second
#
# Author: Dogan Ibrahim
# File  : MPU6050temp.py
# Date  : March, 2022
#----------------------------------------------------------
#
# Library modules used in the program
#
from imu import MPU6050
import utime
from machine import Pin, I2C, SPI
from ST7735 import TFT
from sysfont import sysfont

#
# Initiaize the I2C and SPI busses
#
i2c = I2C(0, sda=Pin(8), scl=Pin(9), freq=400000)
imu = MPU6050(i2c)

spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

#
# Main program. Read and display the temperature
#
def main():
    tft.initg()
    tft.rgb(True)
    
    while True:
       tft.fill(TFT.BLACK)
       T = imu.temperature
       tft.text((5, 10), "Temperature", TFT.WHITE, sysfont, 2, nowrap=True)
       tft.text((10, 50), "T= {:.2f} C".format(T), TFT.WHITE, sysfont, 2, nowrap=True)
       utime.sleep(1)

if __name__ == "__main__":
    main()
