#---------------------------------------------------------
#		ON-OFF TEMPERATURE CONTROL
#		==========================
#
# In this program the DHT11 sensor module is used
# together with the relay module and the blue LED. The
# room temperature is measured every 3 seconds. If the
# temperature is below a set value then the relay and the
# LED are activated. If on the other hand the room temperature
# is above the set value then both the relay and the LED are
# turned OFF.
#
# Author: Dogan Ibrahim
# File  : ONOFF.py
# Date  : March, 2022
#----------------------------------------------------------
import utime
from dht import DHT11
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin

#
# Initialize the SPI
#
spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)
tft.initg()
tft.rgb(True)

#
# Set the SetTemp, configure LED and relay
#
SetTemp = 24.0								# Set point
BLED = Pin(20, Pin.OUT)						# Blue LED
Relay = Pin(26, Pin.OUT)					# Relay
BLED.value(1)								# BLED OFF
Relay.value(0)								# Relay OFF
t = 24.0

#
# Display heading
#
def Heading():
   global SetTemp, t
   tft.fill(TFT.WHITE)						# Clear screen
   tft.rect((5, 10), (110, 100), TFT.RED)
   tft.text((15, 40), "TEMP CONTROL", TFT.BLACK, sysfont, 
   1.3, nowrap=True)
   tft.hline((15,51),90, TFT.RED)
   
   tft.text((15, 60), "SetTemp:{:.2f}C".format(SetTemp), TFT.BLUE, 
   sysfont, 1.1, nowrap=True)

   tft.text((15, 75), "   Room:{:.2f}C".format(t), TFT.RED, 
   sysfont, 1.1, nowrap=True)
   
   if Relay.value() == 1:
      tft.text((30, 100), "RELAY ON", TFT.RED, sysfont, 1.1, nowrap=True)
   else:
      tft.text((30, 100), "RELAY OFF", TFT.BLUE, sysfont, 1.1, nowrap=True)

#
# Read the ambient temperature every 3 seconds and decide
# what to do
#
while True:
    try:
       pin = Pin(16, Pin.OUT, Pin.PULL_DOWN)
       sensor = DHT11(pin)
       sensor.measure()
       t  = sensor.temperature()			# Read temp
       if SetTemp > t:						# If greater
         Relay.value(1)						# Relay ON
         BLED.value(0)						# BLED ON
       else:
         Relay.value(0)						# Relay OFF
         BLED.value(1)						# BLED OFF
       Heading()							# Heading
    except:									# Error reading
         utime.sleep(10)
         continue
    utime.sleep(10)
    
    

    
