#---------------------------------------------------------
#		CHASING LEDs
#		============
#
# In this program the 3 on-board LEDs are rotated left to
# give teh effect of chasing each other
#
# Author: Dogan Ibrahim
# File  : Rotate.py
# Date  : February, 2022
#----------------------------------------------------------
from machine import Pin
import utime

yellow = Pin(18, Pin.OUT)
green = Pin(19, Pin.OUT)
blue = Pin(20, Pin.OUT)

while True:
    blue.value(0)
    utime.sleep(0.5)
    blue.value(1)
    green.value(0)
    utime.sleep(0.5)
    green.value(1)
    yellow.value(0)
    utime.sleep(0.5)
    yellow.value(1)
