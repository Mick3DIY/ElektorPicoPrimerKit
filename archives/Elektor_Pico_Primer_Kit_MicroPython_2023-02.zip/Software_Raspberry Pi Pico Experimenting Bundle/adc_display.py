#---------------------------------------------------------
#		             VOLTMETER
#		             =========
#
# This is a voltmeter project. The potentiometer is connected
# to connector CN5 of the development board. The analogue
# voltage is measured and displayed on the TFT display as
# the potentiometer arm is moved
#
# Author: Dogan Ibrahim
# File  : adc_display.py
# Date  : March, 2022
#
# Note: This program has been taken from the Makerfabs web
# site and has been modified slightly for the book
#----------------------------------------------------------
import machine
import utime
from ST7735 import TFT
from sysfont import sysfont
from machine import SPI, Pin, ADC
import math

#
# Initialize the SPI bus
#
spi = SPI(1, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(10), mosi=Pin(11), miso=Pin(12))

tft = TFT(spi, 14, 15, 13)

adc = ADC(machine.Pin(26))                # ADC at GP26

#
# Main program. Display the static part of the display. Also
# display the voltage read as a number and as a horizontal
# rectangle (i.e. barchart)
#
def main():
    tft.initg()
    tft.rgb(True)
    tft.fill(TFT.BLACK)
    tft.text((50, 0), "Display ADC", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.text((10, 70), "0V", TFT.WHITE, sysfont, 1, nowrap=True)
    tft.text((100, 70), "3.3V", TFT.WHITE, sysfont, 1, nowrap=True)

    while True:
        adc_value = adc_read()
        tft.fillrect((10, 50), (128, 10), TFT.BLACK)
        tft.fillrect((10, 50), ((int)(100 * (adc_value / 3.3)), 10), TFT.RED)
        tft.text((0, 15), "Volt:{:.2f} V".format(
            adc_value), TFT.WHITE, sysfont, 1, nowrap=True)
        utime.sleep_ms(500)

#
# Read the analogue voltage from pin GP26. Read 10 values
# and then calculate and return the average value
#
def adc_read():
    total = 0.0
    
    for i in range(10):                    # 10 readings
        adc_value = adc.read_u16()         # Read analogue
        adc_v = adc_value / 65536 * 3.3    # Convert to volts
        total = total + adc_v              # The total
        
    total = total / 10.0                   # Calculate average
    return total                           # Return the total

if __name__ == "__main__":
    main()
