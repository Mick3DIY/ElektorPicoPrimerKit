#-----------------------------------------------------------------
#			FLASHING THE YELLOW LED
#			=======================
#
# In this program the yellow on-board LED is flashed every second
#
# Author: Dogan Ibrahim
# File  : YellowFlash2.py
# Date  : February, 2022
#------------------------------------------------------------------
from machine import Pin
import utime

YLED = Pin(18, Pin.OUT)		# Yellow LED at GP18

try:

   while True:			# DO FOREVER
      YLED.value(0)		# LED ON
      utime.sleep(1)		# Wait 1 second
      YLED.value(1)		# LED ON
      utime.sleep(1)		# Wait 1 second

except KeyboardInterrupt:
   pass
   
    
    