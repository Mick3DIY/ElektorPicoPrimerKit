#---------------------------------------------------------
#		BUTTONS AND LEDs
#		================
#
# In this program the three buttons and three LEDs are
# used. Pressing a button continuously flashes the
# corresponding LED at a rate of 500ms
#
# Author: Dogan Ibrahim
# File  : test_button.py
# Date  : February, 2022
#
# Note: This program has been taken from the Makerfabs
# web site and has been modified slightly for the book
#----------------------------------------------------------
import utime
from machine import Pin

#
# Configure the buzzer, LEDs and buttons
#
buzzer = Pin(4, Pin.OUT)
YLED = Pin(18, Pin.OUT)
GLED = Pin(19, Pin.OUT)
BLED = Pin(20, Pin.OUT)

button_1 = Pin(2, Pin.IN, Pin.PULL_UP)
button_2 = Pin(3, Pin.IN, Pin.PULL_UP)
button_3 = Pin(22, Pin.IN, Pin.PULL_UP)

buzzer.value(1)                            # Buzzer ON
utime.sleep_ms(500)                        # 500ms delay
buzzer.value(0)                            # Buzzer OFF

YLED.value(0)                              # YLED ON
GLED.value(0)                              # GLED ON
BLED.value(0)                              # BLED ON

#
# Flash the corresponding LED if a button is kept presed
#
while(True):
    if button_1.value() == 0:              # Button 1 pressed
        YLED.toggle()                      # Togle YLED
    if button_2.value() == 0:              # Button 2 presssed
        GLED.toggle()                      # Toggle GLED
    if button_3.value() == 0:              # Button 3 pressed
        BLED.toggle()                      # Toggle BLED
    utime.sleep_ms(500)                    # 500ms delay
    
